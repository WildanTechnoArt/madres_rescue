package com.unpi.madres

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_circulate_message.*

class CirculateMessageActivity : AppCompatActivity() {

    private// must check the result to prevent exception
    val firstTwilioSMS: String
        get() {
            @SuppressLint("Recycle") val cursor =
                contentResolver.query(Uri.parse("content://sms/inbox"), null, null, null, null)!!

            if (cursor.moveToFirst()) {

                do {
                    for (idx in 0 until cursor.columnCount) {
                        if (cursor.getColumnName(idx) == "body" && cursor.getString(idx).contains("Twilio")) {
                            return cursor.getString(idx)
                        }
                    }
                } while (cursor.moveToNext())

            }

            return "No message found!!"

        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_circulate_message)

        val message = firstTwilioSMS
        etMessageSetter.setText(message)

        fab_button.setOnClickListener {
            circulateMessage()
        }
    }

    private fun circulateMessage() {
        val text = etMessageSetter.text.toString().trim { it <= ' ' }
        if (text != "No message found!!" && text != "") {
            CirculateMessageActivity.sendMessages(text)
            Toast.makeText(context, "Message has been forwarded to all your Contacts", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(context, "Please check the input message", Toast.LENGTH_LONG).show()
        }

    }

    companion object {

        @SuppressLint("StaticFieldLeak")
        lateinit var context: Context

        private fun sendMessages(MessageBody: String) {
            val phoneNumbers = RetrieveContactList.getList(context)
            for (i in phoneNumbers.indices) {
                DeliverMessages.sendSms(phoneNumbers[i], MessageBody)
            }

        }
    }
}