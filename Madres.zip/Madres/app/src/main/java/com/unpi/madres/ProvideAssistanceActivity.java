package com.unpi.madres;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ProvideAssistanceActivity extends AppCompatActivity {

    private static final String PREFERENCE = "preference";
    @SuppressLint("StaticFieldLeak")
    static TextView tvCountry, tvLocation;
    @SuppressLint("StaticFieldLeak")
    static TextView tvAmbulance, tvFire, tvPolice, tvCordinates;
    static String ambulance, fire, police;
    static RetrievePresentDistressState distressState;
    private PopupWindow popupWindow;
    @SuppressLint("StaticFieldLeak")
    static private Button webViewButton, fabButton;
    @SuppressLint("StaticFieldLeak")
    static Context context;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_provide_assistance);
        context = this;

        tvCountry = findViewById(R.id.tvCountry1);
        tvLocation = findViewById(R.id.tvLocation1);
        tvCordinates = findViewById(R.id.tvCordinates1);
        fabButton = findViewById(R.id.fab_button);

        relativeLayout = findViewById(R.id.assistanceMasterLayout);
        webViewButton = findViewById(R.id.bWebView1);

        //noinspection ConstantConditions
        MyDBHandler db = new MyDBHandler(this);
        FetchCountryData.Companion.getCountryCode(this, db.getWritableDatabase(), 2);

        fabButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFabClick();
            }
        });
    }

    @SuppressLint("SetTextI18n")
    public static void setLocationText(Country country, Location location, String countryShortId) {
        tvLocation.setText("Found You!!");
        tvCountry.setText(country.getName());
        tvCordinates.setText("( " + location.getLatitude() + ", " + location.getLongitude() + " )");
        RetrievePresentDistressState distressState = new RetrievePresentDistressState();
        distressState.currentScenario(country.getId(), 2);
        ambulance = country.getAmbulanceNumber();
        fire = country.getFireNumber();
        police = country.getPoliceNumber();

    }

    @SuppressLint("SetTextI18n")
    public void onFabClick() {

        Button bClose;

        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View layout = inflater.inflate(R.layout.popout_emergency,
                (ViewGroup) findViewById(R.id.layout_popout)
        );

        popupWindow = new PopupWindow(layout, 700, 1000, true);
        popupWindow.showAtLocation(layout, Gravity.CENTER, 0, 0);
        relativeLayout.setVisibility(View.GONE);

        tvAmbulance = layout.findViewById(R.id.tvAmbulance);
        tvFire = layout.findViewById(R.id.tvFire);
        tvPolice = layout.findViewById(R.id.tvPolice);

        tvAmbulance.setText("0000" + ambulance);
        tvFire.setText("0000" + fire);
        tvPolice.setText("0000"+police);

        bClose = layout.findViewById(R.id.bClosePop);
        bClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
                relativeLayout.setVisibility(View.VISIBLE);
            }
        });
    }

    public static void callWebView(String html) {
        final String passHtml = html;

        webViewButton.setVisibility(View.VISIBLE);
        webViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, WebViewActivity.class);

                SharedPreferences.Editor editor = context.getSharedPreferences(PREFERENCE, MODE_PRIVATE).edit();
                editor.putString("html", passHtml);
                editor.apply();

                context.startActivity(intent);
            }
        });
    }
}