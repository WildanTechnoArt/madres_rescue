package com.unpi.madres

/**
 * Created by rohit on 20/8/15.
 */
class Country(
    val id: Int,
    val name: String,
    val fireNumber: String,
    val policeNumber: String,
    val ambulanceNumber: String
)
