package com.unpi.madres;


public class testClass {

    void test(){

    }
}
