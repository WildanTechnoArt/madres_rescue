package com.unpi.madres

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.location.Location
import android.util.Log
import android.widget.Toast

import com.loopj.android.http.AsyncHttpResponseHandler
import com.loopj.android.http.JsonHttpResponseHandler
import com.loopj.android.http.RequestParams

import org.apache.http.Header
import org.json.JSONException
import org.json.JSONObject
import java.lang.IllegalArgumentException

import java.util.ArrayList

class FetchCountryData {

    companion object {
        private var countryShortId: String? = null
        private const val TAG = "MADRES"
        private var database: SQLiteDatabase? = null
        private var country: String? = null
        private var countries: ArrayList<Country>? = null

        //Parsing Json data and making an arraylist of Country
        private fun parseJsonCountryList(json: JSONObject): ArrayList<Country> {
            Log.v(TAG, "FetchCountryData parseJsonCountryList")
            val countryList = ArrayList<Country>()
            try {
                val jsonArray = json.getJSONArray("data")
                val count = json.getInt("count")
                for (i in 0 until count) {
                    var country: Country
                    val id = jsonArray.getJSONObject(i).getInt("id")
                    val name = jsonArray.getJSONObject(i).getJSONObject("fields").getString("name")
                    country = try {
                        val fireNumber = EmergencyContacts.contacts?.getJSONObject(name)?.getString("fire")
                        val policeNumber = EmergencyContacts.contacts?.getJSONObject(name)?.getString("police")
                        val ambulanceNumber = EmergencyContacts.contacts?.getJSONObject(name)?.getString("ambulance")
                        Country(id, name, fireNumber.toString(), policeNumber.toString(), ambulanceNumber.toString())
                    } catch (e: JSONException) {
                        Country(id, name, "", "", "")
                    }

                    countryList.add(country)
                }
            } catch (e: JSONException) {
                Log.e(TAG, e.toString())
            }

            return countryList
        }

        private fun insertCountries(database: SQLiteDatabase?, countries: ArrayList<Country>) {
            Log.v(TAG, "FetchCountryData insertCountries")
            for (country in countries) {
                val values = ContentValues()
                values.put(MyDBHandler.COUNTRY_COLUMN_CODE, country.id)
                values.put(MyDBHandler.COUNTRY_COLUMN_NAME, country.name)
                values.put(MyDBHandler.COUNTRY_EMERGENCY_FIRE_NUMBER, country.fireNumber)
                values.put(MyDBHandler.COUNTRY_EMERGENCY_POLICE_NUMBER, country.policeNumber)
                values.put(MyDBHandler.COUNTRY_EMERGENCY_AMBULANCE_NUMBER, country.ambulanceNumber)
                Log.i(TAG, values.toString())
                try {
                    val l = database!!.insertOrThrow(MyDBHandler.TABLE_COUNTRY, null, values)
                    Log.i(TAG, "INSERT :$l")
                } catch (e: SQLException) {
                    Log.e(TAG, e.toString())
                }

            }
        }

        //Fetching Json List of countries from ReliefWeb
        fun insertCountriesIntoDatabase(db: SQLiteDatabase) {
            Log.v(TAG, "FetchCountryData insertCountriesIntoDatabase")
            database = db
            val params = RequestParams()
            params.put("offset", "0")
            params.put("limit", "250")

            ReliefWebRestClient.get("countries", params, object : AsyncHttpResponseHandler() {
                override fun onSuccess(statusCode: Int, headers: Array<Header>, responseBody: ByteArray) {
                    Log.i(TAG, "inside ReliefWebRestClient.get")
                    var response: JSONObject? = null
                    try {
                        response = JSONObject(String(responseBody))
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }

                    countries = parseJsonCountryList(response!!)

                }

                override fun onFailure(statusCode: Int, headers: Array<Header>, responseBody: ByteArray, error: Throwable) {

                }

                override fun onFinish() {
                    super.onFinish()
                    insertCountries(database, countries!!)
                }
            })
            ReliefWebRestClient.get("countries", params, object : JsonHttpResponseHandler() {
                override fun onSuccess(statusCode: Int, headers: Array<Header>, response: JSONObject) {
                    Log.i(TAG, "inside ReliefWebRestClient.get")
                    val countries = parseJsonCountryList(response)
                    insertCountries(database, countries)
                }
            })
        }

        private fun getLocation(context: Context): Location? {
            Log.v(TAG, "FetchCountryData getLocation")
            val gps = GPSLocator(context)
            // check if GPS enabled
            return if (gps.canGetLocation()) {
                gps.location
            } else null
        }

        @SuppressLint("Recycle")
        fun getCountryCodeFromCountryName(db: SQLiteDatabase, countryName: String?): Int {
            val cursor = db.query(
                MyDBHandler.TABLE_COUNTRY, arrayOf(MyDBHandler.COUNTRY_COLUMN_CODE),
                MyDBHandler.COUNTRY_COLUMN_NAME + " = ? ", arrayOf(countryName.toString()), null, null, null
            )
            cursor.moveToFirst()
            Log.i(TAG, "Cursor :$cursor")
            var countryCode = 0
            if (!cursor.isAfterLast)
                countryCode = cursor.getInt(0)
            cursor.getColumnIndex(MyDBHandler.COUNTRY_COLUMN_CODE)
            return countryCode
        }

        @SuppressLint("Recycle")
        fun getCountryByCountryCode(db: SQLiteDatabase, code: String): Country? {
            val cursor = db.query(
                MyDBHandler.TABLE_COUNTRY,
                arrayOf(
                    MyDBHandler.COUNTRY_COLUMN_NAME,
                    MyDBHandler.COUNTRY_EMERGENCY_FIRE_NUMBER,
                    MyDBHandler.COUNTRY_EMERGENCY_AMBULANCE_NUMBER,
                    MyDBHandler.COUNTRY_EMERGENCY_POLICE_NUMBER
                ),
                MyDBHandler.COUNTRY_COLUMN_CODE + " = ? ", arrayOf(code), null, null, null
            )
            cursor.moveToFirst()
            var c: Country? = null
            if (!cursor.isAfterLast)
                c = Country(
                    Integer.parseInt(code),
                    cursor.getString(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3)
                )
            return c
        }

        // finding Country Name from Coordinates Using geonames api
       fun getCountryCode(context: Context, db: SQLiteDatabase, selector: Int) {
            Log.v(TAG, "FetchCountryData getCountryCode")
            val location = getLocation(context)
            val params = RequestParams()
            params.put("lat", location?.latitude)
            params.put("lng", location?.longitude)
            params.put("username", "madres")
            var countryCode: Int
            GeoNameRESTClient.get("", params, object : AsyncHttpResponseHandler() {
                override fun onSuccess(statusCode: Int, headers: Array<Header>, responseBody: ByteArray) {
                    val response = JSONObject(String(responseBody))
                    try {
                        country = response.getJSONArray("geonames").getJSONObject(0).getString("countryName")
                        countryShortId = response.getJSONArray("geonames").getJSONObject(0).getString("countryCode")
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                }

                override fun onFailure(statusCode: Int, headers: Array<Header>, responseBody: ByteArray, error: Throwable) {

                }

                @SuppressLint("Recycle")
                override fun onFinish() {
                    super.onFinish()

                    try{
                        Log.i(TAG, "JSON :$country")
                        Log.i(TAG, "COUNTRY NAME : $country")
                        val cursor = db.query(
                            MyDBHandler.TABLE_COUNTRY, arrayOf(MyDBHandler.COUNTRY_COLUMN_CODE),
                            MyDBHandler.COUNTRY_COLUMN_NAME + " = ? ", arrayOf(country), null, null, null
                        )
                        cursor.moveToFirst()
                        Log.i(TAG, "Cursor :$cursor")

                        countryCode = cursor.getInt(0)
                        if (!cursor.isAfterLast)
                            cursor.getColumnIndex(MyDBHandler.COUNTRY_COLUMN_CODE)
                        val countryCodeName = getCountryCodeFromCountryName(db, country)

                        Log.i(TAG, "COUNTRY CODE :$countryCode")
                        Toast.makeText(context, "$country : $countryCode", Toast.LENGTH_LONG).show()

                        val c = getCountryByCountryCode(db, Integer.toString(countryCodeName))
                        Log.i(TAG, "Country code :" + c!!.id)
                        when (selector) {
                            0 -> VictimActivity.setLocationText(c, location, countryShortId.toString())
                            2 -> ProvideAssistanceActivity.setLocationText(c, location, countryShortId)
                        }
                    }catch (ex: IllegalArgumentException){
                        ex.printStackTrace()
                    }
                }
            })
        }
    }
}
