package com.unpi.madres

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class MyDBHandler(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    //Query yang digunakan untuk mengupgrade Tabel
    private val SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS " + MyDBHandler.DB_NAME

    init {
        Log.v(TAG, "MyDBHandler Constructor")
    }

    override fun onCreate(db: SQLiteDatabase) {
        Log.v(TAG, "MyDBHandler onCreate")
        //Generating Country Table
        val queryCountryTable = "CREATE TABLE " + TABLE_COUNTRY + " (" +
                COUNTRY_COLUMN_CODE + " INTEGER PRIMARY KEY, " +
                COUNTRY_COLUMN_NAME + " TEXT ," +
                COUNTRY_EMERGENCY_POLICE_NUMBER + " TEXT ," +
                COUNTRY_EMERGENCY_AMBULANCE_NUMBER + " TEXT ," +
                COUNTRY_EMERGENCY_FIRE_NUMBER + " TEXT " +
                ");"
        db.execSQL(queryCountryTable)
        FetchCountryData.insertCountriesIntoDatabase(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        Log.v(TAG, "MyDBHandler onUpgrade")
        db.execSQL(SQL_DELETE_ENTRIES)
        onCreate(db)
    }

    companion object {
        const val TAG = "MADRES"
        const val DB_VERSION = 2
        const val DB_NAME = "madres.db"
        const val TABLE_COUNTRY = "country"
        const val COUNTRY_COLUMN_CODE = "_id"
        const val COUNTRY_COLUMN_NAME = "name"
        const val COUNTRY_EMERGENCY_FIRE_NUMBER = "fire"
        const val COUNTRY_EMERGENCY_POLICE_NUMBER = "police"
        const val COUNTRY_EMERGENCY_AMBULANCE_NUMBER = "ambulance"
    }
}
