package com.unpi.madres;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class VictimActivity extends Activity {

    private static final String PREFERENCE = "preference";
    @SuppressLint("StaticFieldLeak")
    static TextView tvCountry, tvLocation, tvCordinates;
    @SuppressLint("StaticFieldLeak")
    static TextView tvAmbulance, tvFire, tvPolice;
    static String ambulance, fire, police;
    static RetrievePresentDistressState distressState;
    @SuppressLint("StaticFieldLeak")
    static Context context;
    private PopupWindow popupWindow;
    @SuppressLint("StaticFieldLeak")
    static private Button webViewButton;
    private RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_victim);
        context = this;
        tvCountry = findViewById(R.id.tvCountry);
        tvLocation = findViewById(R.id.tvLocation);
        tvCordinates = findViewById(R.id.tvCordinates);
        Button fabButton = findViewById(R.id.fab_button);

        webViewButton = findViewById(R.id.bWebView);

        relativeLayout = findViewById(R.id.victimMasterLayout);

        MyDBHandler db = new MyDBHandler(this);
        FetchCountryData.Companion.getCountryCode(this, db.getWritableDatabase(), 0);
        //Toast.makeText(this,FetchCountryData.Companion.getCountryByCountryCode(db.getWritableDatabase(), Integer.toString(119)).getId(),Toast.LENGTH_LONG).show();

        fabButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFabClick();
            }
        });
    }

    private static ProgressDialog progressDialog;

    static String MessageBody;
    @SuppressLint("SetTextI18n")
    public static void setLocationText(Country country, Location location, String countryShortId) {
        tvLocation.setText("Found You!!");
        tvCountry.setText(country.getName());
        tvCordinates.setText("( " + location.getLatitude() + ", " + location.getLongitude() + " )");
        RetrievePresentDistressState distressState = new RetrievePresentDistressState();
        distressState.currentScenario(country.getId(), 0);
        ambulance =  country.getAmbulanceNumber();
        fire = country.getFireNumber();
        police = country.getPoliceNumber();
        MessageBody = "Test Tes 123"
                + country.getName() + " ( " + location.getLatitude() + ", " + location.getLongitude() + " )";

        //Adding Dialogue Box
        AlertDialog alertDialog = new AlertDialog.Builder(context)
                .setTitle("Sending Distress")
                .setMessage("Are you sure you want to send distress message to all your contacts?")
                .setPositiveButton("Send Distress Message", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        VictimActivity.sendMessages(MessageBody);
                        Toast.makeText(context, "All your Contacts have been informed", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(context, "Cancelled", Toast.LENGTH_SHORT).show();
                    }
                })
                .setIcon(R.drawable.alert)
                .create();
        alertDialog.show();
    }

    public static void sendMessages(String MessageBody) {
        ArrayList<String> phoneNumbers = RetrieveContactList.Companion.getList(context);
        for (int i = 0; i < phoneNumbers.size(); i++) {
            DeliverMessages.Companion.sendSms(phoneNumbers.get(i), MessageBody);
        }

    }

    @SuppressLint("SetTextI18n")
    public void onFabClick() {

        Button bClose;

        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View layout = inflater.inflate(R.layout.popout_emergency,
                (ViewGroup) findViewById(R.id.layout_popout)
        );

        popupWindow = new PopupWindow(layout, 700, 1000, true);
        popupWindow.showAtLocation(layout, Gravity.CENTER, 0, 0);
        relativeLayout.setVisibility(View.GONE);

        tvAmbulance = layout.findViewById(R.id.tvAmbulance);
        tvFire = layout.findViewById(R.id.tvFire);
        tvPolice = layout.findViewById(R.id.tvPolice);

        tvAmbulance.setText("0000" + ambulance);
        tvFire.setText("0000" + fire);
        tvPolice.setText("0000" + police);

        bClose = layout.findViewById(R.id.bClosePop);
        bClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
                relativeLayout.setVisibility(View.VISIBLE);
            }
        });

    }

    public static void callWebView(String html) {
        final String passHtml = html;

        webViewButton.setVisibility(View.VISIBLE);
        webViewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, WebViewActivity.class);

                SharedPreferences.Editor editor = context.getSharedPreferences(PREFERENCE, MODE_PRIVATE).edit();
                editor.putString("html", passHtml);
                editor.apply();

                context.startActivity(intent);
            }
        });
    }
}