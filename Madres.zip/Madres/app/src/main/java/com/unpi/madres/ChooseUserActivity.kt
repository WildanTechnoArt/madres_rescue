package com.unpi.madres

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_choose_user.*

class ChooseUserActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_user)

        //Activating GPS
        val gps = GPSLocator(this)
        if (!gps.isGPSEnabled) {
            gps.showSettingsAlert()
        }

        fb_victim.setOnClickListener {
            startActivity(Intent(this@ChooseUserActivity, VictimActivity::class.java))
        }

        fb_family.setOnClickListener {
            startActivity(Intent(this@ChooseUserActivity, FamilyActivity::class.java))
        }

        fb_volunteer.setOnClickListener {
            startActivity(Intent(this@ChooseUserActivity, VolunteerActivity::class.java))
        }
    }
}