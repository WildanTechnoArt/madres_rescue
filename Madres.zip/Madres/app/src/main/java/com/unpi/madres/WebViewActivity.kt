package com.unpi.madres

import android.annotation.SuppressLint
import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_web_view.*

class WebViewActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web_view)

        context = this

        val preferences = getSharedPreferences(PREFERENCE, Context.MODE_PRIVATE)
        val html = preferences.getString("html", null)
        webView!!.loadData(html, "text/html", "UTF-8")
    }

    companion object {

        private const val PREFERENCE = "preference"
        @SuppressLint("StaticFieldLeak")
        private var context: Context? = null
    }
}
