package com.unpi.madres;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.apache.http.Header;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;

public class JobActivity extends AppCompatActivity {

    private Context context;

    private static final String PREFERENCE = "preference";
    @SuppressLint("StaticFieldLeak")
    private static EditText etJobCountry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job);
        context = this;
        etJobCountry = findViewById(R.id.etJobCountry);
        Button fabButton = findViewById(R.id.fab_button);
        fabButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitForm();
            }
        });
    }

    class Job {
        String title;
        String link;

        Job(String title, String link) {
            this.title = title;
            this.link = link;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getLink() {
            return link;
        }

        public void setLink(String link) {
            this.link = link;
        }
    }

    static ArrayList<Job> jobs;
    static ProgressDialog progressDialog;
    static String response;

    public void submitForm() {
        //noinspection ConstantConditions
        MyDBHandler db = new MyDBHandler(this);
        int countryCode = FetchCountryData.Companion.getCountryCodeFromCountryName(db.getWritableDatabase(),
                etJobCountry.getText().toString().trim());
        if(countryCode == 0) {
            Toast.makeText(context, "Please enter the correct country",Toast.LENGTH_LONG).show();
            return;
        }
        String BASE_URL = "http://reliefweb.int/jobs?country=" + countryCode;
        AsyncHttpClient client = new AsyncHttpClient();
        client.get(BASE_URL, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                response = new String(responseBody);
            }

            @Override
            public void onStart() {
                super.onStart();
                progressDialog = ProgressDialog.show(context, "Processing...",
                        "Finding relevant information. Please wait.");
            }

            @Override
            public void onFinish() {
                super.onFinish();
                parseResponse(response);
                progressDialog.dismiss();
                Intent intent = new Intent(context, WebViewActivity.class);
                context.startActivity(intent);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
    }

    private void parseResponse(String response) {
        jobs = new ArrayList<>();
//        Toast.makeText(this, response, Toast.LENGTH_LONG).show();
        String BASE_URL = "http://reliefweb.int";
        Document document = Jsoup.parseBodyFragment(response);
        Elements items = document.getElementsByClass("item");
        for (Element item : items) {
            try {
                Elements links = item.getElementsByTag("a");
                String text = links.get(2).text();
                String href = links.get(2).attr("href");
                Job job = new Job(text, BASE_URL + href);
                jobs.add(job);
            } catch (Exception e) {
                //      Log.e("PARSE", e.toString());
            }
        }
        makeHtml(jobs);
    }

    private void makeHtml(ArrayList<Job> jobs) {
        StringBuilder html = new StringBuilder("<h2 style=\"text-align: center;\"><u>Jobs Near You</u></h2>\n");
        for (Job job : jobs) {
            html.append("<h3>").append(job.getTitle()).append("</h3>\n");
            html.append("<a href=\"").append(job.getLink()).append("\"> Click HERE </a>\n<hr>");
        }
        //Log.i("HTML", html);
        SharedPreferences.Editor editor = getSharedPreferences(PREFERENCE, MODE_PRIVATE).edit();
        editor.putString("html", html.toString());
        editor.apply();

    }
}