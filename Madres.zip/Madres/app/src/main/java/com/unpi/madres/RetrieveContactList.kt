package com.unpi.madres

import android.annotation.SuppressLint
import android.content.Context
import android.provider.ContactsContract

import java.util.ArrayList

class RetrieveContactList {

    companion object {
        @SuppressLint("Recycle")
        fun getList(context: Context): ArrayList<String> {
            val strings = ArrayList<String>()
            try {
                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null,
                    null,
                    null,
                    null
                )!!.use { cursor ->
                    val contactIdIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone._ID)
                    val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val phoneNumberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    //            int photoIdIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_ID);
                    cursor.moveToFirst()
                    do {
                        val phoneNumber = cursor.getString(phoneNumberIdx)
                        strings.add(phoneNumber)
                    } while (cursor.moveToNext())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            return strings
        }
    }
}
