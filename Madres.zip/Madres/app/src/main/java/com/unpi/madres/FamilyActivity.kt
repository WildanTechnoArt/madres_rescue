package com.unpi.madres

import android.animation.Animator
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_family.*

class FamilyActivity : AppCompatActivity() {

    private var rowContainer: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_family)
        webViewButton = findViewById<View>(R.id.bWebView) as Button

        fab_button.setOnClickListener {
            onFabClick()
        }
    }

    override fun onBackPressed() {


        for (i in 0 until ll_container!!.childCount) {
            val rowView = ll_container!!.getChildAt(i)
            rowView.animate()
                .setStartDelay((i * SCALE_DELAY).toLong())
                .scaleX(0f).scaleY(0f)
                .setListener(object : Animator.AnimatorListener {
                    override fun onAnimationStart(animation: Animator) {}

                    override fun onAnimationEnd(animation: Animator) {
                        finishAfterTransition()
                    }

                    override fun onAnimationCancel(animation: Animator) {}

                    override fun onAnimationRepeat(animation: Animator) {}
                })
        }
    }

    private fun onFabClick() {
        val countryName = etLocation!!.text.toString().trim { it <= ' ' }
        val name = etName!!.text.toString().trim { it <= ' ' }
        val db = MyDBHandler(this)
        val countryCode = FetchCountryData.getCountryCodeFromCountryName(db.writableDatabase, countryName)
        val country = FetchCountryData.getCountryByCountryCode(db.writableDatabase, Integer.toString(countryCode))
        val retrievePresentDistressState = RetrievePresentDistressState()
        retrievePresentDistressState.currentScenario(countryCode, 1)
        MessageBody = ""
        if (countryCode == 0)
            Toast.makeText(this@FamilyActivity, "Please Enter the Country Name correctly!", Toast.LENGTH_LONG).show()
        else {
            MessageBody = ("Urgent! Need Help!\n\r" + etName!!.text + " is stuck in"
                    + etLocation!!.text + "\n\rPlease provide assistance in any way possible and Please spread the word around.")

            val alertDialog = AlertDialog.Builder(context)
                .setTitle("Sending Distress")
                .setMessage("Are you sure you want to send distress message to all your contacts?")
                .setPositiveButton("Send Distress Message") { _, _ ->
                    FamilyActivity.sendMessages(MessageBody)
                    Toast.makeText(context, "All your Contacts have been informed", Toast.LENGTH_LONG).show()
                    MessageBody =
                            ("Here are some Emergency Numbers for your area!\n\rAmbulance: " + country?.ambulanceNumber
                                    + "\n\rFire: " + country?.fireNumber + "\n\rPolice: " + country?.policeNumber)

                    if (etPhone!!.text.toString().trim { it <= ' ' } != "") {
                        DeliverMessages.sendSms(etPhone!!.text.toString(), MessageBody)
                        Toast.makeText(context, "Emergency Contacts delivered to Victim", Toast.LENGTH_LONG).show()
                    }
                }
                .setNegativeButton(
                    "Cancel"
                ) { _, _ -> Toast.makeText(context, "Cancelled", Toast.LENGTH_SHORT).show() }
                .setIcon(R.drawable.alert)
            alertDialog.show()

        }


    }

    companion object {

        private const val PREFERENCE = "preference"
        private const val SCALE_DELAY = 120
        @SuppressLint("StaticFieldLeak")
        private var etName: EditText? = null
        @SuppressLint("StaticFieldLeak")
        private var etLocation: EditText? = null
        @SuppressLint("StaticFieldLeak")
        private var etPhone: EditText? = null
        @SuppressLint("StaticFieldLeak")
        private var webViewButton: Button? = null
        @SuppressLint("StaticFieldLeak")
        internal lateinit var context: Context
        val EXTRA_HTML = "com.bitshifter.wildfire.familyActivity.EXTRA_HTML"
        internal lateinit var MessageBody: String

        private fun sendMessages(MessageBody: String) {
            val phoneNumbers = RetrieveContactList.getList(context)
            for (i in phoneNumbers.indices) {
                DeliverMessages.sendSms(phoneNumbers[i], MessageBody)
            }
        }

        fun callWebView(html: String) {

            webViewButton!!.visibility = View.VISIBLE
            webViewButton!!.setOnClickListener {
                val intent = Intent(context, WebViewActivity::class.java)

                val editor = context.getSharedPreferences(PREFERENCE, Context.MODE_PRIVATE).edit()
                editor.putString("html", html)
                editor.apply()

                context.startActivity(intent)
            }

        }
    }

}