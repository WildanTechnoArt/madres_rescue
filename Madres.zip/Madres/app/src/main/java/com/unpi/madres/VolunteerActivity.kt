package com.unpi.madres

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_volunteer.*

class VolunteerActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_volunteer)
        fab_button.setOnClickListener {
            onFabClick()
        }
        bhelp.setOnClickListener {
            provideAssistance()
        }
        bSpread.setOnClickListener {
            circulateMessage()
        }
    }

    private fun provideAssistance() {
        startActivity(Intent(this@VolunteerActivity, ProvideAssistanceActivity::class.java))
    }

    private fun circulateMessage() {
        startActivity(Intent(this@VolunteerActivity, CirculateMessageActivity::class.java))
    }

    private fun onFabClick() {
        startActivity(Intent(this@VolunteerActivity, JobActivity::class.java))
    }
}